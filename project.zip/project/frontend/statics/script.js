console.log("Script is working!");
